
public class CmdAddTeamMember extends RecordedCommand {

	private Employee e;
	private Team t;
	@Override
	public void execute(String[] cmdParts) {
		try {
			if(cmdParts.length < 3)
				throw new ExInsufficientCommand();
				
			Company company = Company.getInstance();
			String teamName = cmdParts[1];
			String empName =cmdParts[2];
			e = company.searchEmployee(empName);
			if(e == null)
				throw new ExEmployeeNotFound();
			t = company.searchTeam(teamName);
			if(t == null)
				throw new ExTeamNotFound();
			
			t.addEmployeeToTeam(e);
			addUndoCommand(this);
			clearRedoList();
			
			System.out.println("Done.");
		} catch (ExInsufficientCommand e) {
			System.out.println(e.getMessage());
		} catch (ExEmployeeNotFound e1) {
			System.out.println(e1.getMessage());
		} catch (ExTeamNotFound e1) {
			System.out.println(e1.getMessage());
		} catch (ExEmployeeAlreadyJoinedToTeam e1) {
			System.out.println(e1.getMessage());
		}
		
	}

	//TBD
	@Override
	public void undoMe() {
		// TODO Auto-generated method stub
		t.removeEmployeeFromTeam(e);
		
		addRedoCommand(this);
	}

	//TBD
	@Override
	public void redoMe() {
		// TODO Auto-generated method stub
		try {
			t.addEmployeeToTeam(e);
		} catch (ExEmployeeAlreadyJoinedToTeam e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		addUndoCommand(this);
	}

}
