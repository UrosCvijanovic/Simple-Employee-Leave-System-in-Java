
public class CmdHire extends RecordedCommand {
	Employee emp;

	@Override
	public void execute(String[] cmdParts) {
		try {
			if (cmdParts.length < 3)
				throw new ExInsufficientCommand();
			
				String empName = cmdParts[1];
				int annLeav = Integer.parseInt(cmdParts[2]);
				if(annLeav > 300 || annLeav < 0)
					throw new ExAnnualLeavesOutOfBound();
				Company company = Company.getInstance();

				company.createEmployee(empName, annLeav);
				emp = company.searchEmployee(empName);

				addUndoCommand(this);
				clearRedoList();
				System.out.println("Done.");
				
		} catch (ExInsufficientCommand e) {
			System.out.println(e.getMessage());
		} catch (ExEmployeeAlredyExists e) {
			System.out.println(e.getMessage());
		} catch(ExAnnualLeavesOutOfBound e) {
			System.out.println(e.getMessage());
		}

	}

	@Override
	public void undoMe() {
		Company company = Company.getInstance();
		company.removeEmployee(emp);
		addRedoCommand(this);
	}

	@Override
	public void redoMe() {
		Company company = Company.getInstance();
		company.addEmployee(emp);
		addUndoCommand(this);

	}

}
