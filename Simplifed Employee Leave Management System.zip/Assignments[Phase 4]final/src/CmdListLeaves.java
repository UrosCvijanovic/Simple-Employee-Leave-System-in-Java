
public class CmdListLeaves implements Command
{

	@Override
	public void execute(String[] cmdParts) {
		Company company = Company.getInstance();
		if(cmdParts.length < 2) {
			company.listAllEmployeeLeaves();
		}
		else {
			String empName = cmdParts[1];
			company.listEmployeeLeaves(empName);
		}
		
	}

}
