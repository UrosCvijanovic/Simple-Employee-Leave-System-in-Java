
public class CmdListRoles implements Command {

	private Employee e;

	@Override
	public void execute(String[] cmdParts) {
		try {
			if (cmdParts.length < 2)
				throw new ExInsufficientCommand();

			Company company = Company.getInstance();

			String empName = cmdParts[1];
			e = company.searchEmployee(empName);
			if (e == null)
				throw new ExEmployeeNotFound();

			company.listTeamsAndRolesForEmp(e);


		} catch (ExInsufficientCommand e) {
			System.out.println(e.getMessage());
		} catch (ExEmployeeNotFound e1) {
			System.out.println(e1.getMessage());
		}
	}

}
