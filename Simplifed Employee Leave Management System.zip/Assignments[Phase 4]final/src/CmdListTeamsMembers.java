
public class CmdListTeamsMembers implements Command {

	@Override
	public void execute(String[] cmdParts) {
		Company company = Company.getInstance();

		company.listMembersOfAllTeamsWithRoles();

	}

}
