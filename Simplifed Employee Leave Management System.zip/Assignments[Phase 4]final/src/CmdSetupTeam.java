
public class CmdSetupTeam extends RecordedCommand
{
	private Employee e;
	private Team t;
	@Override
	public void execute(String[] cmdParts) {
		try {
			if(cmdParts.length < 3)
				throw new ExInsufficientCommand();
				
			Company company = Company.getInstance();
			String teamName = cmdParts[1];
			String empName =cmdParts[2];
			e = company.searchEmployee(empName);
			if(e == null)
				throw new ExEmployeeNotFound();
			
			t = company.createTeam(teamName, e);
			addUndoCommand(this);
			clearRedoList();
			
			System.out.println("Done.");
		} catch (ExInsufficientCommand e) {
			System.out.println(e.getMessage());
		} catch (ExEmployeeNotFound e1) {
			System.out.println(e1.getMessage());
		} catch (ExTeamAlredyExists e1) {
			System.out.println(e1.getMessage());
		}
		
	}

	@Override
	public void undoMe() {
		Company company = Company.getInstance();
		company.removeTeam(t);
		
		addRedoCommand(this);
	}

	@Override
	public void redoMe() {
		Company company = Company.getInstance();
		company.addTeam(t);
		
		addUndoCommand(this);
	}

}
