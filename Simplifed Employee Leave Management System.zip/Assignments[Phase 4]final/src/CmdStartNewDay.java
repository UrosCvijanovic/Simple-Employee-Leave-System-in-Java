
public class CmdStartNewDay extends RecordedCommand
{
	
	private String newDay;
	private String oldDay;

	@Override
	public void execute(String[] cmdParts) {
		try {
			if(cmdParts.length < 2)
				throw new ExInsufficientCommand();
			SystemDate systemDate = SystemDate.getInstance();
			newDay = cmdParts[1];
			oldDay = systemDate.toString();
			systemDate.set(newDay);
			
			addUndoCommand(this);
			clearRedoList();
			
			System.out.println("Done.");
			
		} catch (ExInsufficientCommand e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public void undoMe() {
		SystemDate systemDate = SystemDate.getInstance();
		systemDate.set(oldDay);

		addRedoCommand(this);
	}

	@Override
	public void redoMe() {
		SystemDate systemDate = SystemDate.getInstance();
		systemDate.set(newDay);
	
		addUndoCommand(this);
	}

	
}
