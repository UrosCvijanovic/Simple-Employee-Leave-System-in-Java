
public class CmdTakeLeave extends RecordedCommand {

	private Employee e;
	private LeaveRecord leave;

	@Override
	public void execute(String[] cmdParts) {
		try {
			if (cmdParts.length < 4)
				throw new ExInsufficientCommand();
			String empName = cmdParts[1];
			String startDate = cmdParts[2];
			String endDate = cmdParts[3];
			Company company = Company.getInstance();
			if (cmdParts.length == 4) {
				
				leave = company.addLeaveForEmployee(empName, startDate, endDate);
			} else if (cmdParts.length > 4) {
				int len = (cmdParts.length - 4) / 2;
				String teamNames[] = new String[len];
				String actingHeadNames[] = new String[len];
				for (int i = 0; i < len; i++) {
					String teamName = cmdParts[4 + i * 2];
					Team team = company.searchTeam(teamName);
					
					if (team == null) {
						throw new ExTeamNotFound();
					}
					String actingHeadName = cmdParts[4 + i * 2 + 1];
					Employee actingHead = company.searchEmployee(actingHeadName);
					LeaveRecord thisLeave = new LeaveRecord(startDate, endDate);
	
					if (actingHead == null) { throw new ExEmployeeNotFoundForTeam(actingHeadName);}
					
					for (LeaveRecord l : actingHead.getEmployeeLeaves()) {
						if (l.ovelaps(thisLeave)) {
							throw new ExEmployeeIsOnLeave(actingHead, l);
						}
					}

					Employee checkEmployee = team.findEmployeeForTeam(actingHead);
					if (checkEmployee == null) {
						throw new ExEmployeeNotFoundForTeam(actingHead);
					}
					teamNames[i] = teamName;
					actingHeadNames[i] = actingHeadName;

				}
				leave = company.addLeaveForEmployee(empName, startDate, endDate, teamNames, actingHeadNames);

			}

			if (leave != null) {
				e = company.searchEmployee(empName);
				addUndoCommand(this);
				clearRedoList();
				System.out.println("Done.");
			}

		} catch (ExInsufficientCommand e) {
			System.out.println(e.getMessage());
	        //catch (ExEmployeeNotFound e) {
			//System.out.println(e.getMessage());
		} catch (ExTeamNotFound e) {
			System.out.println(e.getMessage());
		} catch (ExEmployeeIsOnLeave e) {
			System.out.println(e.getMessage());
		} catch (ExEmployeeNotFoundForTeam e) {
			System.out.println(e.getMessage());
		}

	}

	@Override
	public void undoMe() {
		Company company = Company.getInstance();
		e.removeLeave(leave);
		addRedoCommand(this);

	}

	@Override
	public void redoMe() {
		Company company = Company.getInstance();
		e.addEmpLeave(leave);
		addUndoCommand(this);
	}

}
