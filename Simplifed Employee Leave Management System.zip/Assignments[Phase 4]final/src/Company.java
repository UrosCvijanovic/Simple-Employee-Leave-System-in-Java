import java.util.ArrayList;
import java.util.Collections;

public class Company {

	private ArrayList<Employee> allEmployees;
	private ArrayList<Team> allTeams;

	private static Company instance = new Company();

	public static Company getInstance() {
		return instance;
	}

	private Company() {
		allEmployees = new ArrayList<>();
		allTeams = new ArrayList<>();
	}

	public void addEmployee(Employee emp) {
		allEmployees.add(emp);
	}

	public void listEmployees() {
		for (Employee emp : allEmployees) {
			System.out.println(emp);
		}
	}

	public Employee searchEmployee(String empName) {
		for (Employee emp : allEmployees) {
			if (emp.getName().equals(empName)) {
				return emp;
			}
		}
		return null;
	}

	public Employee createEmployee(String empName, int annLeav) throws ExEmployeeAlredyExists {
		Employee searchEmp = null;
		searchEmp = searchEmployee(empName);
		if (searchEmp == null) {
			Employee emp = new Employee(empName, annLeav);
			allEmployees.add(emp);
			Collections.sort(this.allEmployees);
			return emp;
		} else {
			throw new ExEmployeeAlredyExists();
		}
	}

	public void removeEmployee(Employee e) {
		allEmployees.remove(e);
	}

	public void addTeam(Team t) {
		allTeams.add(t);
	}

	public Team searchTeam(String teamName) {
		for (Team team : allTeams) {
			if (team.getName().equals(teamName)) {
				return team;
			}
		}
		return null;
	}

	public Team createTeam(String teamName, Employee e) throws ExTeamAlredyExists {
		Team searchTeam = null;
		searchTeam = searchTeam(teamName);
		if (searchTeam == null) {
			Team t = new Team(teamName, e);
			allTeams.add(t);
			Collections.sort(allTeams);
			return t;
		} else {
			throw new ExTeamAlredyExists();
		}

	}

	private LeaveRecord manageLeave(String empName, String sDate, String eDate, String[] teamName,
			String[] actingHeadName) {
		Employee employee = searchEmployee(empName);
		LeaveRecord leave = new LeaveRecord(sDate, eDate, teamName, actingHeadName);
		try {

			int leaveDuration = leave.countDays();

			if (employee.getAnnualLeaves() < employee.numberOfDaysUsed() + leaveDuration) {
				throw new ExInsufficientBalance(employee.getAnnualLeaves() - employee.numberOfDaysUsed());
			}

			Day currentDate = SystemDate.getInstance();
			Day startDate = leave.getStartDate();
			if (startDate.isBefore(currentDate)) {
				throw new ExLeaveWrongDate();
			}

			LeaveRecord possibleOverlapLeave = employee.isOverLapedLeave(leave);
			if (possibleOverlapLeave != null) {
				throw new ExLeaveOverLaped(possibleOverlapLeave);
			}

			employee.addEmpLeave(leave);
			return leave;

		} catch (ExInsufficientBalance e) {
			System.out.println(e.getMessage());
		} catch (ExLeaveWrongDate e) {
			System.out.println(e.getMessage());
		} catch (ExLeaveOverLaped e) {
			System.out.println(e.getMessage());
		}

		return null;
	}

	public LeaveRecord addLeaveForEmployee(String empName, String sDate, String eDate) {
		return manageLeave(empName, sDate, eDate, null, null);
	}

	public LeaveRecord addLeaveForEmployee(String empName, String sDate, String eDate, String[] teamName,
			String[] actingHeadName) throws ExEmployeeIsOnLeave {

		return manageLeave(empName, sDate, eDate, teamName, actingHeadName);

	}

	public void removeTeam(Team t) {
		allTeams.remove(t);

	}

	public void listTeams() {
		Team.listTeams(allTeams);
	}

	public void listAllEmployeeLeaves() {
		Employee.listLeaves(allEmployees);

	}

	public void listEmployeeLeaves(String empName) {
		Employee emp = searchEmployee(empName);
		Employee.listEmpLeaves(emp);

	}

	public void listTeamsAndRolesForEmp(Employee emp) {
		boolean flag = false;
		for (Team te : allTeams) { // for every team
			if (te.getTeamMembers().contains(emp)) { // if emp member
				flag = true;
				if (emp.equals(te.getHead())) {
					System.out.println(te.getName() + " (Head of Team)");
				} else {
					System.out.println(te.getName() + "");

				}
			}
		}
		if (flag == false) {
			System.out.println("No role");
		}
	}

	public void listMembersOfAllTeamsWithRoles() {
		boolean flag = false;
		for (Team te : allTeams) { // for every team
			Collections.sort(te.getTeamMembers());
			System.out.println(te.getName() + ":");
			for (Employee emp : te.getTeamMembers()) {
				if (emp.equals(te.getHead())) {
					System.out.println(emp.getName() + " (Head of Team)");
				} else {
					System.out.println(emp.getName() + "");
				}
			}
			if (te.getHead().getEmployeeLeaves().size() > 0) {
				System.out.println("Acting heads:");
				for (LeaveRecord lr : te.getHead().getEmployeeLeaves()) {
					if (lr.getTeamNames() != null) {
						for (int i = 0; i < lr.getTeamNames().length; i++) {
							if (te.getName().equals(lr.getTeamNames()[i])) {
								System.out.println(lr.toString() + ": " + lr.getActingHeads()[i]);
							}
						}
					}
				}
			}

			System.out.println("");
		}
	}

	public ArrayList<Team> getAllTeams() {
		return allTeams;
	}
	
	

}
