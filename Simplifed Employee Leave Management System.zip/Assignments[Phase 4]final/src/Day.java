
import java.io.*;
import java.util.Scanner;

public class Day implements Cloneable, Comparable <Day>
{
	
	private int year;
	private int month;
	private int day;
	
	private static final String monthNames = "JanFebMarAprMayJunJulAugSepOctNovDec";
	
	//Constructor
	public Day(int y, int m, int d) {
		this.year=y;
		this.month=m;
		this.day=d;		
	}
	
	public Day(String sDay) {
		set(sDay);
	}
	
	public void set(String sDay) {
		String [] dateParts = sDay.split("-");
		this.day = Integer.parseInt(dateParts[0]);
		this.month = monthNames.indexOf(dateParts[1])/3+1;
		this.year = Integer.parseInt(dateParts[2]);
	}
	// check if a given year is a leap year
	static public boolean isLeapYear(int y)
	{
		if (y%400==0)
			return true;
		else if (y%100==0)
			return false;
		else if (y%4==0)
			return true;
		else
			return false;
	}
	
	// check if y,m,d valid
	static public boolean valid(int y, int m, int d)
	{
		if (m<1 || m>12 || d<1) return false;
		switch(m){
			case 1: case 3: case 5: case 7:
			case 8: case 10: case 12:
					 return d<=31; 
			case 4: case 6: case 9: case 11:
					 return d<=30; 
			case 2:
					 if (isLeapYear(y))
						 return d<=29; 
					 else
						 return d<=28; 
		}
		return false;
	}

	// Return a string for the day like dd MMM yyyy
	@Override
	public String toString() {
		
		/*final String[] MonthNames = {
				"Jan", "Feb", "Mar", "Apr",
				"May", "Jun", "Jul", "Aug",
				"Sep", "Oct", "Nov", "Dec"};*/
		
		return  day+"-"+ monthNames.substring((month-1)*3,(month)*3) + "-"+ year; // (month-1)*3,(month)*3;
	}
	
	  public boolean isEndOfTheMonth() {
			 if(valid(year, month, day+1)) {
				 return false;
			 }
			 else {
				 return true;
			 }
		 }
		  
		  public Day next() {
			  if(isEndOfTheMonth()) {
				  if(month == 12) 
					  return new Day(year+1, 1, 1);
				  else
					  return new Day(year, month+1, 1);
				  }
			  else {
				  return new Day(year, month, day+1);
			  }
		  }
	
	@Override
	public Day clone()
	{
	Day copy=null;
	try {
		copy = (Day) super.clone();
	} catch (CloneNotSupportedException e) {
		System.out.println("Cloning Not Supported");
		e.printStackTrace();
	}
	return copy;
	}
	
	
	@Override
	public boolean equals(Object otherObject)
	{
		if(otherObject == null)
			return false;
		if(this.getClass() != otherObject.getClass())
			return false;
		Day otherDay = (Day) otherObject;
		if(day != otherDay.day)
			return false;
		if(month != otherDay.month)
			return false;
		if(year != otherDay.year)
			return false;
		return true;
	}
	

	@Override
	public int compareTo(Day otherDay) {
		int thisDay = ((year * 10000) + (month * 100) + day);
		int anotherDay = ((otherDay.year * 10000) + (otherDay.month * 100) + otherDay.day);
		if(thisDay == anotherDay) 
			return 0;
		else if(thisDay > anotherDay)
			return 1;
		else
			return -1;
	}
	
	public boolean isBefore(Day end) {
		if (this.year < end.year)
			return true;
		else if (this.month < end.month)
			return true;
		else if (this.day < end.day)
			return true;
		else
			return false;
	}

	public int getYear() {
		return year;
	}

	public int getMonth() {
		return month;
	}

	public int getDay() {
		return day;
	}

}