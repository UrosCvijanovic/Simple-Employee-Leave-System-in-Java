import java.util.ArrayList;
import java.util.Collections;

public class Employee implements Comparable<Employee>
{
	
		private String name;
		private int annualLeaves;
		private ArrayList<LeaveRecord> employeeLeaves;
		
		public Employee(String name, int annualLeaves) {
			this.name = name;
			this.annualLeaves = annualLeaves;
			employeeLeaves = new ArrayList<>();
		}

		public String getName() {
			return name;
		}
		
		public void addEmpLeave(LeaveRecord l) {
			employeeLeaves.add(l);
			Collections.sort(employeeLeaves);
		}
		
		public String toString() {
			return String.format("%s (Entitled Annual Leaves: %d days)", name, annualLeaves);
		}

		@Override
		public int compareTo(Employee anotherEmployee) {
			return this.name.compareTo(anotherEmployee.name);
			/*
			if(this.name.equals(anotherEmployee.name)) {
				return 0;
			}
			else if(this.name.compareTo(anotherEmployee.name) > 0) {
				return 1;
			}
			else {
				return -1;
			}
			*/
		}

		public void removeLeave(LeaveRecord leave) {
			employeeLeaves.remove(leave);
			
		}

		public static void listLeaves(ArrayList<Employee> allEmployees) {
			for(Employee emp: allEmployees) {
				System.out.println(emp.getName() + ":");
				if(emp.employeeLeaves.size() == 0) {
					System.out.println("No leave record");
				}
				else {
				for(LeaveRecord leave: emp.employeeLeaves) {
					System.out.println(leave.toString());
				}
			}
		}	
	}

		public static void listEmpLeaves(Employee emp) {
			if(emp.employeeLeaves.size() == 0) {
				System.out.println("No leave record");
			}
			else {
				for(LeaveRecord leave: emp.employeeLeaves) {
					System.out.println(leave.toString());
				}
			}
		}

		public int getAnnualLeaves() {
			return annualLeaves;
		}
		
		public int numberOfDaysUsed() {
			int count = 0;
			for(LeaveRecord lr : employeeLeaves) {			
			    count += lr.countDays();
				}
			return count;
		}
		
		public LeaveRecord isOverLapedLeave(LeaveRecord newLeave) {
			//we go through all leaves, and if and we stop it.
			for (LeaveRecord leave : employeeLeaves) {
				if(leave.ovelaps(newLeave)) return leave;
			}
			return null;
		}

		public ArrayList<LeaveRecord> getEmployeeLeaves() {
			return employeeLeaves;
		}
		
		
}
