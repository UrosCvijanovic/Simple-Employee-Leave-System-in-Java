
public class ExAnnualLeavesOutOfBound extends Exception {
	private static final long serialVersionUID = 1L;
	
	public ExAnnualLeavesOutOfBound() {
		super("Out of range (Entitled Annual Leaves should be within 0-300)!");
	}
	public ExAnnualLeavesOutOfBound(String message) {
		super(message);
	}
}
