
public class ExEmployeeAlreadyJoinedToTeam extends Exception {
	private static final long serialVersionUID = 1L;

	public ExEmployeeAlreadyJoinedToTeam() {
		super("The employee has joined the team already!");
	}

	public ExEmployeeAlreadyJoinedToTeam(String message) {
		super(message);
	}
}
