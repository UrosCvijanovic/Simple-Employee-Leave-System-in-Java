
public class ExEmployeeAlredyExists extends Exception
{
	private static final long serialVersionUID = 1L;
	
	public ExEmployeeAlredyExists() {
		super("Employee already exists!");
	}
	public ExEmployeeAlredyExists(String message) {
		super(message);
	}

}
