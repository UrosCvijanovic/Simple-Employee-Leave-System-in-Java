
public class ExEmployeeIsOnLeave extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ExEmployeeIsOnLeave(Employee emp, LeaveRecord l) {
		super(emp.getName() + " is on leave during " + l.toString() + "!");
	}
	public ExEmployeeIsOnLeave(String message) {
		super(message);
	}
}
