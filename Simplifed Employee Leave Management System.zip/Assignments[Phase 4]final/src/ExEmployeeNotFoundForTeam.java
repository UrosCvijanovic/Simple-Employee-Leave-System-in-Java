
public class ExEmployeeNotFoundForTeam extends Exception {
	private static final long serialVersionUID = 1L;

	public ExEmployeeNotFoundForTeam(Employee actingHead) {
		super("Employee (" + actingHead.getName() + ") not found for Production Team!");
	}
	
	public ExEmployeeNotFoundForTeam(String message) {
		super("Employee (" + message + ") not found for Production Team!");
	}
}
