
public class ExInsufficientBalance extends Exception {
	
	private static final long serialVersionUID = 1L;
	private int remainingDays;
	
	public ExInsufficientBalance(int remainingDays) {
		super("Insufficient balance. "+remainingDays+" days left only!");
		this.remainingDays = remainingDays;
	}
	public ExInsufficientBalance(String message) {
		super(message);
	}
}
