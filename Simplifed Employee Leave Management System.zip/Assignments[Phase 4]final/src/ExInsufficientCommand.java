
public class ExInsufficientCommand extends Exception {
	private static final long serialVersionUID = 1L;
	
	public ExInsufficientCommand() {
		super("Insufficient command arguments!");
	}
	public ExInsufficientCommand(String message) {
		super(message);
	}

}
