
public class ExLeaveOverLaped extends Exception {

	private static final long serialVersionUID = 1L;

	public ExLeaveOverLaped(LeaveRecord possibleOverlapLeave) {
		super("Leave overlapped: The leave period " + possibleOverlapLeave + " is found!");
	}

	public ExLeaveOverLaped(String message) {
		super(message);
	}
}
