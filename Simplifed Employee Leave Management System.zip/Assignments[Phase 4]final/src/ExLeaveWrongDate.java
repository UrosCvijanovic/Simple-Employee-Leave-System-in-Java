
public class ExLeaveWrongDate extends Exception {
	
	
	//Wrong Date.  System date is already 10-Feb-2020!
	
	private static final long serialVersionUID = 1L;

	public ExLeaveWrongDate() {
		super("Wrong Date.  System date is already "+SystemDate.getInstance()+"!");
	}

	public ExLeaveWrongDate(String message) {
		super(message);
	}
}
