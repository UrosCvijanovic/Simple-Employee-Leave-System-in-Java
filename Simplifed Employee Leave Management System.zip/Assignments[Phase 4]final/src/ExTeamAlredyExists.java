
public class ExTeamAlredyExists extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ExTeamAlredyExists() {
		super("Team already exists!");
	}
	
	public ExTeamAlredyExists(String message) {
		super(message);
	}
}
