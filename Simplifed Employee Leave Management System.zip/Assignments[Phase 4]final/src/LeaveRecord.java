
public class LeaveRecord implements Comparable<LeaveRecord> {

	private Day startDate;
	private Day endDate;
	private String[] teamName;
	private String[] actingHead;

	public LeaveRecord(String startDate, String endDate) {
		this.startDate = new Day(startDate);
		this.endDate = new Day(endDate);
		this.actingHead = null;
		this.teamName = null;
	}
	
	public LeaveRecord(String startDate, String endDate, String[] teamName, String[] actingHead) {
		super();
		this.startDate = new Day(startDate);
		this.endDate = new Day(endDate);
		this.teamName = teamName;
		this.actingHead = actingHead;
	}


	public Day getStartDate() {
		return startDate;
	}

	public Day getEndDate() {
		return endDate;
	}

	public String toString() {
		return String.format("%s to %s", startDate.toString(), endDate.toString());
	}

	public Day createDayOutOfLeave(String leave) {
		Day leaveAsDay = new Day(leave);
		return leaveAsDay;
	}

	public int countDays() {
		Day start = this.startDate;
		Day end = this.endDate;
		int count = 0;
		while (!end.isBefore(start)) {
			start = start.next();
			count++;
		}
		return count;
	}

	public boolean ovelaps(LeaveRecord newLeave) {
		// proverava i vraca da li se dva Leave-a preklapaju na bilo koji nacin.
		Day start = newLeave.startDate;
		Day end = newLeave.endDate;

		// NE PREKLAPAJU SE,
		// ako je pocetak novog POSLE KRAJA Starog, ili
		if (this.endDate.isBefore(start))
			return false;
		// ako je kraj novog pre pocetka starog.
		if (end.isBefore(this.startDate))
			return false;

		return true;
	}

	@Override
	public int compareTo(LeaveRecord another) {
		if (this.startDate.getYear() == another.startDate.getYear()) {
			if (this.startDate.getMonth() == another.startDate.getMonth()) {
				return (this.startDate.getDay() - another.startDate.getDay());
			} else {
				return (this.startDate.getMonth() - another.startDate.getMonth());
			}
		} else {
			return (this.startDate.getYear() - another.startDate.getYear());
		}
	}

	public boolean isDayInLeave(Day day) {
		return !day.isBefore(startDate) && !endDate.isBefore(day);
	}

	public String[] getTeamNames() {
		return teamName;
	}

	public String[] getActingHeads() {
		return actingHead;
	}
	
	
}
