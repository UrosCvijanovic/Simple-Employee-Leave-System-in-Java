import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Team implements Comparable<Team> {

	private String teamName;
	private Employee head;
	private Day dateSetup;
	private List<Employee> teamMembers;

	public Team(String teamName, Employee head) {
		this.teamName = teamName;
		this.head = head;
		this.dateSetup = SystemDate.getInstance().clone();
		this.teamMembers = new ArrayList<>();
		this.teamMembers.add(head); // check if needs to be done.
	}

	public String toString() {
		return String.format("%-30s%-10s%-13s\n", this.teamName, head.getName(), dateSetup.toString());
	}

	public static void listTeams(ArrayList<Team> allTeams) {
		System.out.printf("%-30s%-10s%-13s\n", "Team Name", "Leader", "Setup Date");
		for (Team team : allTeams) {
			System.out.print(team);
		}
	}

	@Override
	public int compareTo(Team another) {
		return this.teamName.compareTo(another.teamName);
	}

	public String getName() {
		// TODO Auto-generated method stub
		return teamName;
	}

	public void addEmployeeToTeam(Employee e) throws ExEmployeeAlreadyJoinedToTeam {
		if (!this.teamMembers.contains(e)) {
			this.teamMembers.add(e);
		} else {
			throw new ExEmployeeAlreadyJoinedToTeam();
		}
	}

	public String getTeamName() {
		return teamName;
	}

	public void removeEmployeeFromTeam(Employee emp) {
		teamMembers.remove(emp);
	}

	public LeaveRecord checkIfHeadIsOnLeave() {
		for (LeaveRecord lr : head.getEmployeeLeaves()) {
			if (lr.isDayInLeave(SystemDate.getInstance())) {
				return lr; // we got his current leave.
			}
		}
		return null; // not on leave
	}

	public Employee getHead() {
		return this.head;
	}

	public List<Employee> getTeamMembers() {
		return teamMembers;
	}

	public Employee findEmployeeForTeam(Employee actingHead) {
		for(Employee emp: this.teamMembers) {
			if(actingHead.equals(emp)) {
				return emp;
			}
		}
		return null;
	}

}
